--Run under public schema
--SETUP
--Import dblink function
CREATE EXTENSION dblink;

--Only run if the dblink already exists
--DROP SERVER tableau CASCADE;

--Create persistent dblink connection
CREATE SERVER tableau FOREIGN DATA WRAPPER dblink_fdw OPTIONS (hostaddr '***your_ip_address', dbname 'workgroup', port '8060');

--Only run if the user mapping already exists
--DROP USER MAPPING IF EXISTS  FOR postgres SERVER tableau;

--Create persistent user mapping
CREATE USER MAPPING FOR postgres SERVER tableau OPTIONS (user 'readonly', password '***your_password');


--TEST
--Establish connection
--SELECT dblink_connect('myconn2', 'tableau');

--Retrieve some rows
--SELECT * FROM dblink('tableau','SELECT name FROM sites') AS t (name varchar);

--Drop connection
--SELECT dblink_disconnect('myconn2');