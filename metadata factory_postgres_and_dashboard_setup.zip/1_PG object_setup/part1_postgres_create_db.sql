﻿CREATE DATABASE "Tableau_Metadata_factory"
       TABLESPACE = pg_default;
