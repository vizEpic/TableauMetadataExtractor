﻿--For vizzes to run from
--Just a logical view that points at the MV
CREATE VIEW tableau_metadata_prd.vw_fields (site_name, workbook_name, size, schedule_names, workbook_num_of_views, datasource_name, updated_at, created_at, owner_name, project_name, field_caption, field_name, remote_column, remote_table, field_source, formula, approximate_count, min_value, max_value, field_not_used, hidden, datasource_filter, create_ts) AS  SELECT mv_fields.site_name,
    mv_fields.workbook_name,
    mv_fields.size,
    mv_fields.schedule_names,
    mv_fields.workbook_num_of_views,
    mv_fields.datasource_name,
    mv_fields.updated_at,
    mv_fields.created_at,
    mv_fields.owner_name,
    mv_fields.project_name,
    mv_fields.field_caption,
    mv_fields.field_name,
    mv_fields.remote_column,
    mv_fields.remote_table,
    mv_fields.field_source,
    mv_fields.formula,
    mv_fields.approximate_count,
    mv_fields.min_value,
    mv_fields.max_value,
    mv_fields.field_not_used,
    mv_fields.hidden,
    mv_fields.datasource_filter,
    mv_fields.create_ts
   FROM tableau_metadata_prd.mv_fields;

--Just a logical view for unused fields
CREATE VIEW tableau_metadata_prd.vw_unused_fields (site_name, datasource_name, field_name, field_captions, used_cnt, unused_cnt, total_cnt, used_as_datasource_filter_cnt, create_ts) AS  SELECT a.site_name,
    a.datasource_name,
    a.field_name,
    string_agg(DISTINCT a.field_caption, ';'::text) AS field_captions,
    (count(1) - count(
        CASE
            WHEN (a.field_not_used = true) THEN 1
            ELSE NULL::integer
        END)) AS used_cnt,
    count(
        CASE
            WHEN (a.field_not_used = true) THEN 1
            ELSE NULL::integer
        END) AS unused_cnt,
    count(1) AS total_cnt,
    count(
        CASE
            WHEN (a.datasource_filter = true) THEN 1
            ELSE NULL::integer
        END) AS used_as_datasource_filter_cnt,
    max(a.create_ts) AS create_ts
   FROM (tableau_metadata_prd.vw_fields a
     JOIN ( SELECT vw_fields.datasource_name,
            vw_fields.site_name,
            vw_fields.field_name
           FROM tableau_metadata_prd.vw_fields
          WHERE (((vw_fields.workbook_name)::text = 'None'::text) AND (vw_fields.hidden = false))) nh USING (datasource_name, site_name, field_name))
  WHERE (((a.workbook_name)::text <> 'None'::text) AND (a.field_name <> '[Number of Records]'::text))
  GROUP BY a.site_name, a.datasource_name, a.field_name
 HAVING ((count(
        CASE
            WHEN (a.field_not_used = true) THEN 1
            ELSE NULL::integer
        END) = count(1)) AND (count(
        CASE
            WHEN (a.datasource_filter = true) THEN 1
            ELSE NULL::integer
        END) = 0));

--Just a logical view for data through fields
CREATE VIEW tableau_metadata_prd.vw_data_thru_background_status (task_origin, task_type, task_name, site_name, schedule_name, task_status, completed_at) AS  SELECT 'Tableau'::text AS task_origin,
    t.obj_type AS task_type,
    o.name AS task_name,
    i.name AS site_name,
    string_agg(s.name, ','::text) AS schedule_name,
        CASE
            WHEN (b.progress = '-1'::integer) THEN 'Pending'::text
            WHEN (b.progress = 0) THEN 'Active'::text
            WHEN (b.finish_code = 0) THEN 'Success'::text
            ELSE 'Failed'::text
        END AS task_status,
    b.completed_at
   FROM ((((tableau_metadata_prd.schedules2 s
     JOIN tableau_metadata_prd.tasks t ON ((s.id = t.schedule_id)))
     JOIN tableau_metadata_prd.sites i ON ((t.site_id = i.id)))
     JOIN ( SELECT 'Workbook'::text AS obj_type,
            workbooks.id,
            workbooks.name,
            workbooks.site_id
           FROM tableau_metadata_prd.workbooks
        UNION
         SELECT 'Datasource'::text AS text,
            datasources.id,
            datasources.name,
            datasources.site_id
           FROM tableau_metadata_prd.datasources) o ON ((((t.obj_type)::text = o.obj_type) AND (t.obj_id = o.id) AND (t.site_id = o.site_id))))
     LEFT JOIN ( SELECT x.progress,
            x.finish_code,
            x.started_at,
            x.completed_at,
            x.title,
            x.subtitle,
            x.site_id
           FROM (tableau_metadata_prd.background_jobs x
             JOIN ( SELECT background_jobs.title,
                    background_jobs.subtitle,
                    background_jobs.site_id,
                    max(background_jobs.created_at) AS created_at
                   FROM tableau_metadata_prd.background_jobs
                  WHERE ((background_jobs.job_name)::text = ANY (ARRAY[('Refresh Extracts'::character varying)::text, ('Increment Extracts'::character varying)::text]))
                  GROUP BY background_jobs.title, background_jobs.subtitle, background_jobs.site_id) y ON ((((x.title)::text = (y.title)::text) AND ((x.subtitle)::text = (y.subtitle)::text) AND (x.site_id = y.site_id) AND (x.created_at = y.created_at))))
          WHERE ((x.job_name)::text = ANY (ARRAY[('Refresh Extracts'::character varying)::text, ('Increment Extracts'::character varying)::text]))) b ON (((t.site_id = b.site_id) AND ((o.name)::text = (b.title)::text) AND ((t.obj_type)::text = (b.subtitle)::text))))
  WHERE (((t.type)::text = ANY (ARRAY[('RefreshExtractTask'::character varying)::text, ('IncrementExtractTask'::character varying)::text])) AND ((i.name)::text = ANY (ARRAY[('Internal'::character varying)::text, ('Marketer'::character varying)::text])))
  GROUP BY o.name, t.obj_type, i.name, b.progress, b.finish_code, b.completed_at;
   

