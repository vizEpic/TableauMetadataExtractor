REM Grant access to large objects
REM
REM Need to be logged in as admin to Tableau repository.  Password can be found within install directory\config\tabsvc.yml
REM 
GRANT SELECT ON pg_catalog.pg_largeobject TO readonly;