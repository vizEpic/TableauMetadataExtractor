﻿CREATE SCHEMA tableau_metadata_stg;

CREATE SCHEMA tableau_metadata_prd;

ALTER USER login_name SET search_path to tableau_metadata_prd

