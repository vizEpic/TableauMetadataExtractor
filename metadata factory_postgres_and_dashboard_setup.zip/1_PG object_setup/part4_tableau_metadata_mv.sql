﻿--Combines all the individual metadata tables into a Materialized View
create materialized view Tableau_metadata_prd.mv_fields
as
(
SELECT
    s.name AS site_name,
    w.name AS workbook_name,
    w.size,
    sch.schedule_names,
    w.view_count         AS workbook_num_of_views,
    a.datasource_caption AS datasource_name,
    w.updated_at,
    w.created_at,
    u.friendly_name AS owner_name,
    p.name          AS project_name,
    a.field_caption,
    a.field_name,
    a.remote_column,
    a.family_name AS remote_table,
    CASE
        WHEN (LENGTH(a.formula) > 0)
        THEN a.formula
        WHEN ((LENGTH(a.formula) = 0)
            AND (LENGTH(b.formula) > 0))
        THEN b.formula
        ELSE a.field_name
    END AS field_source,
    CASE
        WHEN (LENGTH(a.formula) = 0)
        THEN b.formula
        ELSE a.formula
    END AS formula,
    (
        CASE
            WHEN ((LENGTH(a.approximate_count) = 0)
                AND (LENGTH(b.approximate_count) = 0))
            THEN NULL::text
            WHEN (LENGTH(a.approximate_count) = 0)
            THEN b.approximate_count
            ELSE a.approximate_count
        END)::INTEGER AS approximate_count,
    CASE
        WHEN (LENGTH(a.min_value) = 0)
        THEN b.min_value
        ELSE a.min_value
    END AS min_value,
    CASE
        WHEN (LENGTH(a.max_value) = 0)
        THEN b.max_value
        ELSE a.max_value
    END AS max_value,
    a.field_not_used,
    a.hidden,
    a.datasource_filter,
    a.create_ts
FROM
    ((((((Tableau_metadata_prd.fields a
LEFT JOIN
    (
        SELECT
            fields.source_type,
            fields.source_id,
            fields.site_id,
            fields.datasource_repository_url,
            fields.datasource_caption,
            fields.datasource_name,
            fields.field_caption,
            fields.field_name,
            fields.remote_column,
            fields.parent_name,
            fields.family_name,
            fields.approximate_count,
            fields.min_value,
            fields.max_value,
            fields.formula,
            fields.create_ts,
            fields.field_not_used,
            fields.hidden,
            fields.datasource_filter
        FROM
            Tableau_metadata_prd.fields
        WHERE
            (
                fields.source_type = 'datasource'::text)) b USING (site_id,
    datasource_repository_url, field_name))
LEFT JOIN
    (
        SELECT
            schedules.source_id,
            schedules.source_type,
            schedules.site_id,
            string_agg(schedules.name, ' | '::text ORDER BY schedules.name) AS schedule_names
        FROM
            Tableau_metadata_prd.schedules
        GROUP BY
            schedules.source_id,
            schedules.source_type,
            schedules.site_id) sch
ON
    (((
                a.source_id = sch.source_id)
        AND (
                a.source_type = sch.source_type)
        AND (
                a.site_id = sch.site_id))))
JOIN
    Tableau_metadata_prd.workbooks w
ON
    (((
                a.source_id = w.id)
        AND (
                a.source_type = 'workbook'::text))))
JOIN
    Tableau_metadata_prd.sites s
ON
    ((
            a.site_id = s.id)))
JOIN
    Tableau_metadata_prd.users u
ON
    ((
            w.owner_id = u.id)))
JOIN
    Tableau_metadata_prd.projects p
ON
    ((
            w.project_id = p.id)))
WHERE
    ((
            a.source_type = 'workbook'::text)
    AND (
            a.field_name <> '[:Measure Names]'::text))
UNION ALL
SELECT
    s.name                    AS site_name,
    'None'::CHARACTER VARYING AS workbook_name,
    w.size,
    sch.schedule_names,
    0                       AS workbook_num_of_views,
    w.name                  AS datasource_name,
    w.extracts_refreshed_at AS updated_at,
    w.first_published_at    AS created_at,
    u.friendly_name         AS owner_name,
    p.name                  AS project_name,
    a.field_caption,
    a.field_name,
    a.remote_column,
    a.family_name AS remote_table,
    CASE
        WHEN (LENGTH(a.formula) > 0)
        THEN a.formula
        WHEN ((LENGTH(a.formula) = 0)
            AND (LENGTH(b.formula) > 0))
        THEN b.formula
        ELSE a.field_name
    END AS field_source,
    CASE
        WHEN (LENGTH(a.formula) = 0)
        THEN b.formula
        ELSE a.formula
    END AS formula,
    (
        CASE
            WHEN ((LENGTH(a.approximate_count) = 0)
                AND (LENGTH(b.approximate_count) = 0))
            THEN NULL::text
            WHEN (LENGTH(a.approximate_count) = 0)
            THEN b.approximate_count
            ELSE a.approximate_count
        END)::INTEGER AS approximate_count,
    CASE
        WHEN (LENGTH(a.min_value) = 0)
        THEN b.min_value
        ELSE a.min_value
    END AS min_value,
    CASE
        WHEN (LENGTH(a.max_value) = 0)
        THEN b.max_value
        ELSE a.max_value
    END AS max_value,
    a.field_not_used,
    a.hidden,
    a.datasource_filter,
    a.create_ts
FROM
    ((((((Tableau_metadata_prd.fields a
LEFT JOIN
    (
        SELECT
            fields.source_type,
            fields.source_id,
            fields.site_id,
            fields.datasource_repository_url,
            fields.datasource_caption,
            fields.datasource_name,
            fields.field_caption,
            fields.field_name,
            fields.remote_column,
            fields.parent_name,
            fields.family_name,
            fields.approximate_count,
            fields.min_value,
            fields.max_value,
            fields.formula,
            fields.create_ts,
            fields.field_not_used,
            fields.hidden,
            fields.datasource_filter
        FROM
            Tableau_metadata_prd.fields
        WHERE
            (
                fields.source_type = 'datasource'::text)) b USING (site_id,
    datasource_repository_url, field_name))
LEFT JOIN
    (
        SELECT
            schedules.source_id,
            schedules.source_type,
            schedules.site_id,
            string_agg(schedules.name, ' | '::text ORDER BY schedules.name) AS schedule_names
        FROM
            Tableau_metadata_prd.schedules
        GROUP BY
            schedules.source_id,
            schedules.source_type,
            schedules.site_id) sch
ON
    (((
                a.source_id = sch.source_id)
        AND (
                a.source_type = sch.source_type)
        AND (
                a.site_id = sch.site_id))))
JOIN
    Tableau_metadata_prd.datasources w
ON
    (((
                a.source_id = w.id)
        AND (
                a.source_type = 'datasource'::text))))
JOIN
    Tableau_metadata_prd.sites s
ON
    ((
            a.site_id = s.id)))
JOIN
    Tableau_metadata_prd.users u
ON
    ((
            w.owner_id = u.id)))
JOIN
    Tableau_metadata_prd.projects p
ON
    ((
            w.project_id = p.id)))
WHERE
    ((
            a.source_type = 'datasource'::text)
    AND (
            a.field_name <> '[:Measure Names]'::text)));