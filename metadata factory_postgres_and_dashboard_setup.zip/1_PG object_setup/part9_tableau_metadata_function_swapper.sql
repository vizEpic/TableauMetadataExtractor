--/
CREATE FUNCTION tableau_metadata_prd.swap_stg_tables ()  RETURNS integer
  VOLATILE
AS $dbvis$
TRUNCATE TABLE tableau_metadata_prd.background_jobs;
INSERT INTO tableau_metadata_prd.background_jobs
SELECT 
id, job_type, progress, args, notes, updated_at, created_at, completed_at, started_at,
        job_name, finish_code, priority, title, created_on_worker, processed_on_worker,
        link, lock_version, backgrounder_id, serial_collection_id, site_id, subtitle,
        language, locale, correlation_id, db_link_create_ts
FROM tableau_metadata_stg.background_jobs;

TRUNCATE TABLE tableau_metadata_prd.tasks;
INSERT INTO tableau_metadata_prd.tasks
SELECT id,schedule_id,type,priority,obj_id,created_at,updated_at,site_id,obj_type,luid,consecutive_failure_count,db_link_create_ts
FROM tableau_metadata_stg.tasks;

TRUNCATE TABLE tableau_metadata_prd.datasources;
INSERT INTO tableau_metadata_prd.datasources
SELECT id, name, repository_url, owner_id, created_at, updated_at, project_id, size, lock_version, state, db_class, db_name, table_name, site_id, revision, repository_data_id, repository_extract_data_id, embedded, incrementable_extracts, refreshable_extracts, data_engine_extracts, extracts_refreshed_at, first_published_at, connectable, is_hierarchical, extracts_incremented_at, luid, asset_key_id, document_version, db_link_create_ts
FROM tableau_metadata_stg.datasources;


TRUNCATE TABLE tableau_metadata_prd.data_connections;
INSERT INTO tableau_metadata_prd.data_connections
SELECT id,server,dbclass,port,username,password,name,dbname,tablename,owner_type,owner_id,created_at,updated_at,caption,site_id,keychain,luid,has_extract,db_link_create_ts 
FROM tableau_metadata_stg.data_connections;


TRUNCATE TABLE tableau_metadata_prd.extracts;
INSERT INTO tableau_metadata_prd.extracts 
SELECT id, workbook_id, descriptor, created_at, updated_at, datasource_id, db_link_create_ts
FROM tableau_metadata_stg.extracts;


TRUNCATE TABLE tableau_metadata_prd.schedules;
INSERT INTO tableau_metadata_prd.schedules 
SELECT id, name, source_id, source_type, site_id, create_ts 
FROM tableau_metadata_stg.schedules;


TRUNCATE TABLE tableau_metadata_prd.schedules2;
INSERT INTO tableau_metadata_prd.schedules2
SELECT id, name, create_ts 
FROM tableau_metadata_stg.schedules2;


TRUNCATE TABLE tableau_metadata_prd.fields;
INSERT INTO tableau_metadata_prd.fields 
SELECT source_type, source_id, site_id, datasource_repository_url, datasource_caption, datasource_name, field_caption, field_name, remote_column, parent_name, family_name, approximate_count, min_value, max_value, formula, create_ts, field_not_used, hidden, datasource_filter
FROM tableau_metadata_stg.fields;



TRUNCATE TABLE tableau_metadata_prd.sites;
INSERT INTO tableau_metadata_prd.sites 
SELECT id, name, url_namespace, status, created_at, updated_at, user_quota, content_admin_mode, storage_quota, metrics_level, status_reason, subscriptions_enabled, custom_subscription_footer, custom_subscription_email, luid, query_limit, authoring_disabled, db_link_create_ts
FROM tableau_metadata_stg.sites;


TRUNCATE TABLE tableau_metadata_prd.views;
INSERT INTO tableau_metadata_prd.views 
SELECT id, name, repository_url, description, created_at, locked, published, read_count, edit_count, datasource_id, workbook_id, index, updated_at, owner_id, fields, title, caption, sheet_id, state, sheettype, site_id, repository_data_id, first_published_at, revision, for_cache_updated_at, luid, db_link_create_ts
FROM tableau_metadata_stg.views;


TRUNCATE TABLE tableau_metadata_prd.workbooks;
INSERT INTO tableau_metadata_prd.workbooks 
SELECT id, name, repository_url, description, created_at, updated_at, owner_id, project_id, view_count, size, embedded, thumb_user, refreshable_extracts, extracts_refreshed_at, lock_version, state, version, checksum, display_tabs, data_engine_extracts, incrementable_extracts, site_id, revision, repository_data_id, repository_extract_data_id, first_published_at, primary_content_url, share_description, show_toolbar, extracts_incremented_at, default_view_index, luid, asset_key_id, document_version, db_link_create_ts 
FROM tableau_metadata_stg.workbooks;

TRUNCATE TABLE tableau_metadata_prd.users;
INSERT INTO tableau_metadata_prd.users 
SELECT id, name, login_at, friendly_name, licensing_role_id, licensing_role_name, domain_id, system_user_id, domain_name, domain_short_name, site_id, db_link_create_ts 
FROM tableau_metadata_stg._users;

TRUNCATE TABLE tableau_metadata_prd.projects;
INSERT INTO tableau_metadata_prd.projects 
SELECT id, name, owner_id, created_at, updated_at, state, description, site_id, special, luid, db_link_create_ts 
FROM tableau_metadata_stg.projects;

TRUNCATE TABLE tableau_metadata_prd.xref_workbook_datasource;
INSERT INTO tableau_metadata_prd.xref_workbook_datasource
SELECT workbook_id, site_id, datasource_repository_url, create_ts
FROM tableau_metadata_stg.xref_workbook_datasource;

UPDATE tableau_metadata_prd.fields u
SET family_name=s.family_name
FROM 
(SELECT site_id,datasource_repository_url, family_name,
split_part(family_name, '.', 1) AS schema_name,
split_part(family_name, '.', 2) AS object_name
FROM tableau_metadata_prd.fields
GROUP BY 1,2,3) s
WHERE LENGTH(s.object_name)>0
AND u.site_id=s.site_id
AND u.datasource_repository_url=s.datasource_repository_url
AND u.family_name=s.object_name;

UPDATE tableau_metadata_prd.fields u
SET approximate_count = CASE WHEN LENGTH(u.approximate_count)=0 THEN s.approximate_count ELSE u.approximate_count END
,min_value = CASE WHEN LENGTH(u.min_value)=0 THEN s.min_value ELSE u.min_value END
,max_value = CASE WHEN LENGTH(u.max_value)=0 THEN s.max_value ELSE u.max_value END
,formula = CASE WHEN LENGTH(u.formula)=0 THEN s.formula ELSE u.formula END
FROM 
(SELECT DISTINCT site_id,datasource_repository_url, family_name,field_name,approximate_count,min_value,max_value,formula
FROM tableau_metadata_prd.fields
where LENGTH(approximate_count)>0 AND LENGTH(datasource_repository_url)>0) s
WHERE u.site_id=s.site_id
AND u.datasource_repository_url=s.datasource_repository_url
AND u.family_name=s.family_name
AND u.field_name=s.field_name;

TRUNCATE TABLE tableau_metadata_stg.blobs;

REFRESH MATERIALIZED VIEW tableau_metadata_prd.mv_fields;

SELECT 1;
$dbvis$ LANGUAGE sql
/
