--/
CREATE FUNCTION tableau_metadata_prd.load_stg_tables ()  RETURNS integer
  VOLATILE
AS $dbvis$
SELECT dblink_copytable('tableau','tableau_metadata_stg','public.datasources','',FALSE); 
SELECT dblink_copytable('tableau','tableau_metadata_stg','public.background_jobs','',FALSE); 
SELECT dblink_copytable('tableau','tableau_metadata_stg','public.extracts','',FALSE); 
SELECT dblink_copytable('tableau','tableau_metadata_stg','public.workbooks','',FALSE); 
SELECT dblink_copytable('tableau','tableau_metadata_stg','public.sites','',TRUE); 
SELECT dblink_copytable('tableau','tableau_metadata_stg','public.views','',TRUE); 
SELECT dblink_copytable('tableau','tableau_metadata_stg','public.projects','',TRUE); 
SELECT dblink_copytable('tableau','tableau_metadata_stg','public._users','',TRUE);
SELECT dblink_copytable('tableau','tableau_metadata_stg','public.data_connections','',TRUE);
SELECT dblink_copytable('tableau','tableau_metadata_stg','public.tasks','',FALSE); 

SELECT dblink_connect('myconn', 'tableau');
DROP TABLE IF EXISTS tableau_metadata_stg.blobs;
CREATE TABLE tableau_metadata_stg.blobs AS
SELECT 
repository_id,source_id,source_type,site_id,string_agg(data,'') AS data,NOW() AS create_ts
 FROM dblink('myconn','
SELECT repository_id,source_id,source_type,site_id,data
FROM (
SELECT
repository_data.id AS repository_id,
repository_data.content,
workbooks.id AS source_id,
workbooks.site_id,
''workbook'' AS source_type
FROM workbooks
        INNER JOIN repository_data
ON repository_data.tracking_id = COALESCE(data_id,reduced_data_id)
UNION 
SELECT
repository_data.id AS repository_id,
repository_data.content,
datasources.id AS source_id,
datasources.site_id,
''datasource'' AS source_type
FROM datasources
        INNER JOIN repository_data
ON repository_data.tracking_id = COALESCE(data_id,reduced_data_id)) AS T
INNER JOIN pg_catalog.pg_largeobject 
ON t.content=pg_largeobject.loid 
order by loid,pageno
')
AS t (repository_id INT,source_id INT ,source_type TEXT,site_id INT, data bytea)
GROUP BY 1,2,3,4;

DROP TABLE IF EXISTS tableau_metadata_stg.schedules;
CREATE TABLE tableau_metadata_stg.schedules AS
SELECT 
id,name,source_id,source_type,site_id,NOW() AS create_ts
 FROM dblink('myconn','
SELECT  s.id
        ,s.name
        ,t.obj_id AS source_id
        ,LOWER(t.obj_type) AS source_type 
        ,t.site_id 
FROM schedules s
INNER JOIN tasks t
        ON s.id=t.schedule_id
WHERE t.type=''RefreshExtractTask''
')
AS t (id INT,name TEXT,source_id INT,source_type TEXT,site_id INT);

DROP TABLE IF EXISTS tableau_metadata_stg.schedules2;
CREATE TABLE tableau_metadata_stg.schedules2 AS
SELECT 
id,name,NOW() AS create_ts
 FROM dblink('myconn','
SELECT  s.id
        ,s.name
        FROM schedules s
where hidden = false
and scheduled_action = 0
')        
AS t (id INT,name TEXT);

SELECT dblink_disconnect('myconn');

SELECT 1;
$dbvis$ LANGUAGE sql
/
