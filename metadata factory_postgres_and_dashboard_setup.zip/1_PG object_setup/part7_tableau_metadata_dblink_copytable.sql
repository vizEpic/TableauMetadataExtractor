--/
CREATE FUNCTION public.dblink_copytable (server text, target_schema text, tablename text, where_filter text, keep_connection boolean)  RETURNS void
  VOLATILE
AS $dbvis$
---------------------------------------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------------------------------------
--	Sample Syntax	---------------------------------------------------------------------------------------------
--	select dblink_copytable('tableau','tableau_metadata','public.data_connections','',FALSE); 
---------------------------------------------------------------------------------------------------------------------
DECLARE 
v_query TEXT;
v_col_def TEXT;
v_schema_name TEXT;
v_table_name TEXT;
v_con_name TEXT; 
v_con_retry_max int;
v_con_retry_cnt int;
v_con_result TEXT;
BEGIN

v_schema_name:=substring(tablename,0,position('.' in tablename));
v_table_name:=substring(tablename,position('.' in tablename)+1);
v_con_name:= 'remote_link_'||current_user;
v_con_retry_max:=10;
v_con_retry_cnt:=0;
v_con_result:='Disconnected';


--remote connection if does not exists
IF (v_con_name != ALL(dblink_get_connections()) OR array_upper(dblink_get_connections(), 1) IS NULL)
THEN 
-- loop until we connect
        LOOP
                BEGIN
                v_con_result:=dblink_connect('' || v_con_name || '','' || server || '');
                        EXCEPTION WHEN sqlclient_unable_to_establish_sqlconnection THEN
                        v_con_retry_cnt:=v_con_retry_cnt+1;
                        RAISE NOTICE 'Connection retry %',v_con_retry_cnt;
                END;
                
                EXIT WHEN v_con_result='OK' OR v_con_retry_cnt>=v_con_retry_max;  
        END LOOP;
END IF;

--get column definition
v_col_def:= col_def 
    FROM dblink(''|| v_con_name || '',
        'SELECT  
string_agg(f.attname||'' ''||pg_catalog.format_type(f.atttypid,f.atttypmod),'','' order by f.attnum  ) as col_def
FROM pg_attribute f  
JOIN pg_class c ON c.oid = f.attrelid  
JOIN pg_namespace n ON n.oid = c.relnamespace     
WHERE f.attnum>0 AND attname NOT LIKE ''%pg.dropped%''
    AND c.relname =  '''|| v_table_name ||'''
    AND n.nspname = '''|| v_schema_name ||''' ')
AS columns_def(col_def TEXT); 


--copy table from remote 
v_query:= 'SELECT *,NOW() AS db_link_create_ts FROM dblink('''|| v_con_name || ''',''SELECT * FROM '||tablename ||' '|| where_filter ||''') AS T('||v_col_def||');';
raise info '%', v_query;
EXECUTE 'CREATE SCHEMA IF NOT EXISTS '|| target_schema ||'';
EXECUTE 'DROP TABLE IF EXISTS '|| target_schema ||'.' || v_table_name ||'';
EXECUTE 'CREATE TABLE '|| target_schema ||'.' || v_table_name ||' AS '||v_query;

--disconnect connection
IF (keep_connection=FALSE)
THEN EXECUTE $$ SELECT dblink_disconnect('$$ || v_con_name || $$') $$;
END IF;

END;
$dbvis$ LANGUAGE plpgsql
/
